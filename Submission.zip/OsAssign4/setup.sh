mknod /dev/encdev c 184 1
mknod /dev/decdev c 185 1
make all
insmod encdev.ko
insmod decdev.ko