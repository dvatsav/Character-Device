rmmod encdev
rmmod decdev
make all
insmod encdev.ko
insmod decdev.ko